"""RPE-Harness: State-driven capability addressing for persistent learning agents."""

__version__ = "1.1.0"
